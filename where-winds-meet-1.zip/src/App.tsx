import { useState, useEffect } from 'react';
import { AuthProvider, useAuth } from './context/AuthContext';
import Header from './components/Header';
import HeroSection from './components/HeroSection';
import FAQSection from './components/FAQSection';
import Footer from './components/Footer';
import LoginModal from './components/LoginModal';
import ProfileModal from './components/ProfileModal';
import GuidesPage from './components/GuidesPage';
import AdminPage from './components/AdminPage';
import ContentPage from './components/ContentPage';
import FloatingChat from './components/FloatingChat';
import { ArrowUp, ChevronRight, Crown } from 'lucide-react';

const contentPages = ['weapons', 'builds', 'sects', 'bosses', 'mystic', 'map', 'cooking', 'tips', 'lifeskills'];

function AppContent() {
  const [showScrollTop, setShowScrollTop] = useState(false);
  const [showLoginModal, setShowLoginModal] = useState(false);
  const [showProfileModal, setShowProfileModal] = useState(false);
  const [currentPage, setCurrentPage] = useState<string>('main');

  useEffect(() => {
    const handleScroll = () => setShowScrollTop(window.scrollY > 600);
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const handleNavigate = (section: string) => {
    if (section === 'home') {
      setCurrentPage('main');
      window.scrollTo({ top: 0, behavior: 'smooth' });
      return;
    }
    // All other sections open as separate pages
    setCurrentPage(section);
    window.scrollTo({ top: 0 });
  };

  const goBack = () => { setCurrentPage('main'); window.scrollTo({ top: 0 }); };
  const scrollToTop = () => window.scrollTo({ top: 0, behavior: 'smooth' });

  const headerProps = {
    activeSection: currentPage === 'main' ? 'home' : currentPage,
    onNavigate: handleNavigate,
    onLoginClick: () => setShowLoginModal(true),
    onProfileClick: () => setShowProfileModal(true),
  };

  const modals = (
    <>
      <LoginModal isOpen={showLoginModal} onClose={() => setShowLoginModal(false)} />
      <ProfileModal isOpen={showProfileModal} onClose={() => setShowProfileModal(false)} />
      <FloatingChat onLoginClick={() => setShowLoginModal(true)} />
      {showScrollTop && (
        <button onClick={scrollToTop}
          className="fixed bottom-20 right-6 z-40 bg-gold-400/20 backdrop-blur-sm border border-gold-400/40 text-gold-400 p-3 rounded-full shadow-lg hover:bg-gold-400/30 transition-all animate-fadeIn cursor-pointer">
          <ArrowUp className="w-5 h-5" />
        </button>
      )}
    </>
  );

  // ---- Sub-pages ----
  if (currentPage === 'guides') {
    return (
      <div className="min-h-screen bg-ink-900 text-ink-100">
        <Header {...headerProps} />
        <GuidesPage onBack={goBack} />
        <Footer />
        {modals}
      </div>
    );
  }

  if (currentPage === 'admin') {
    return (
      <div className="min-h-screen bg-ink-900 text-ink-100">
        <Header {...headerProps} />
        <AdminPage onBack={goBack} />
        <Footer />
        {modals}
      </div>
    );
  }

  if (currentPage === 'faq') {
    return (
      <div className="min-h-screen bg-ink-900 text-ink-100">
        <Header {...headerProps} />
        <div className="pt-16 md:pt-20">
          <FAQSection />
        </div>
        <Footer />
        {modals}
      </div>
    );
  }



  if (contentPages.includes(currentPage)) {
    return (
      <div className="min-h-screen bg-ink-900 text-ink-100">
        <Header {...headerProps} />
        <ContentPage pageId={currentPage} onBack={goBack} />
        <Footer />
        {modals}
      </div>
    );
  }

  // ---- Main Page ----
  return <MainPage {...headerProps} modals={modals} onNavigate={handleNavigate} />;
}

function MainPage({ activeSection, onNavigate, onLoginClick, onProfileClick, modals }: {
  activeSection: string; onNavigate: (s: string) => void; onLoginClick: () => void; onProfileClick: () => void;
  modals: React.ReactNode;
}) {
  const { isAdmin, siteSettings } = useAuth();
  const activeAnnouncements = siteSettings.announcements.filter(a => a.active);

  return (
    <div className="min-h-screen bg-ink-900 text-ink-100">
      <Header activeSection={activeSection} onNavigate={onNavigate} onLoginClick={onLoginClick} onProfileClick={onProfileClick} />

      <main>
        {/* Announcements — marquee ticker */}
        {activeAnnouncements.length > 0 && (
          <div className="pt-16 md:pt-20">
            {activeAnnouncements.map(ann => (
              <div key={ann.id} className={`overflow-hidden py-3 border-b ${
                ann.type === 'warning' ? 'bg-orange-500/10 border-orange-500/20' :
                ann.type === 'success' ? 'bg-jade-400/10 border-jade-400/20' :
                'bg-blue-500/10 border-blue-500/20'
              }`}>
                <div className={`animate-marquee whitespace-nowrap text-base md:text-lg font-medium ${
                  ann.type === 'warning' ? 'text-orange-400' :
                  ann.type === 'success' ? 'text-jade-400' :
                  'text-blue-400'
                }`}>
                  <span className="mx-8">
                    {ann.type === 'warning' ? '⚠️' : ann.type === 'success' ? '✅' : 'ℹ️'} {ann.text}
                  </span>
                  <span className="mx-8">
                    {ann.type === 'warning' ? '⚠️' : ann.type === 'success' ? '✅' : 'ℹ️'} {ann.text}
                  </span>
                  <span className="mx-8">
                    {ann.type === 'warning' ? '⚠️' : ann.type === 'success' ? '✅' : 'ℹ️'} {ann.text}
                  </span>
                </div>
              </div>
            ))}
          </div>
        )}

        <div id="home">
          <HeroSection />
        </div>

        {/* Floating Admin Button */}
        {isAdmin() && (
          <button
            onClick={() => onNavigate('admin')}
            className="fixed left-4 top-20 md:top-24 z-40 flex items-center gap-3 bg-ink-900/85 backdrop-blur-md
                     border border-purple-500/35 rounded-xl px-4 py-3 shadow-xl shadow-black/40
                     hover:bg-purple-500/10 hover:border-purple-500/55 hover:-translate-y-0.5 transition-all cursor-pointer group"
          >
            <div className="w-9 h-9 rounded-xl bg-purple-500/20 flex items-center justify-center group-hover:scale-110 transition-transform shrink-0">
              <Crown className="w-4 h-4 text-purple-400" />
            </div>
            <div className="text-left hidden sm:block">
              <div className="font-serif text-sm font-bold text-white group-hover:text-purple-300 transition-colors">
                Панель управления
              </div>
              <div className="text-ink-400 text-[10px]">
                Администратор сайта
              </div>
            </div>
            <ChevronRight className="w-4 h-4 text-ink-400 group-hover:text-purple-400 group-hover:translate-x-0.5 transition-all shrink-0 hidden sm:block" />
          </button>
        )}
      </main>

      <Footer />
      {modals}
    </div>
  );
}



export default function App() {
  return (
    <AuthProvider>
      <AppContent />
    </AuthProvider>
  );
}
